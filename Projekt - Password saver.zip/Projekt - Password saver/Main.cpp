//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Main.h"
#include "PasswordSaverXML.h"
#include "Lozinka.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::FormCreate(TObject *Sender)
{
	_di_IXMLPasswordSaverType PasswordSaver = GetPasswordSaver(XMLDocument1);

	ListView1->Items->Clear();
	for(int i = 0; i < PasswordSaver->Count;i++)
	{
		ListView1->Items->Add();
		ListView1->Items->Item[i]->Caption = PasswordSaver->Site[i]->Name;
		ListView1->Items->Item[i]->SubItems->Add(PasswordSaver->Site[i]->Username);
		ListView1->Items->Item[i]->SubItems->Add(PasswordSaver->Site[i]->Password);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
	 _di_IXMLPasswordSaverType PasswordSaver = GetPasswordSaver(XMLDocument1);
	 _di_IXMLSiteType Site = PasswordSaver->Add();

	 Site->Name = LEStranica->Text;
	 Site->Username = LEIme->Text;
	 String encodedmessage;
	 SCode->Password = "admin";
	 SCode->EncryptString(LELozinka->Text, encodedmessage, TEncoding::UTF8);
	 Site->Password = encodedmessage;
	 XMLDocument1->SaveToFile(XMLDocument1->FileName);
	 ucitaj->Click();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ucitajClick(TObject *Sender)
{
	_di_IXMLPasswordSaverType PasswordSaver = GetPasswordSaver(XMLDocument1);

	ListView1->Items->Clear();
	for(int i = 0; i < PasswordSaver->Count;i++)
	{
		ListView1->Items->Add();
		ListView1->Items->Item[i]->Caption = PasswordSaver->Site[i]->Name;
		ListView1->Items->Item[i]->SubItems->Add(PasswordSaver->Site[i]->Username);
		ListView1->Items->Item[i]->SubItems->Add(PasswordSaver->Site[i]->Password);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
	 _di_IXMLPasswordSaverType PasswordSaver = GetPasswordSaver(XMLDocument1);
	 PasswordSaver->Delete(ListView1->ItemIndex);
	 XMLDocument1->SaveToFile(XMLDocument1->FileName);
     ucitaj->Click();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button4Click(TObject *Sender)
{
	_di_IXMLPasswordSaverType PasswordSaver = GetPasswordSaver(XMLDocument1);
	_di_IXMLSiteType Site = PasswordSaver->Site[ListView1->ItemIndex];

	 Site->Name = LEStranica->Text;
	 Site->Username = LEIme->Text;
	 String encodedmessage;
	 SCode->Password = "admin";
	 SCode->EncryptString(LELozinka->Text, encodedmessage, TEncoding::UTF8);
	 Site->Password = encodedmessage;
	 XMLDocument1->SaveToFile(XMLDocument1->FileName);
	 ucitaj->Click();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ListView1Click(TObject *Sender)
{
	if(ListView1->ItemIndex < 0) return;
	_di_IXMLPasswordSaverType PasswordSaver = GetPasswordSaver(XMLDocument1);
	_di_IXMLSiteType Site = PasswordSaver->Site[ListView1->ItemIndex];

    LELozinka->PasswordChar = '*';

	 LEStranica->Text = Site->Name;
	 LEIme->Text = Site->Username;
	 LELozinka->Text = Site->Password;


}
//---------------------------------------------------------------------------

void __fastcall TForm1::BOtkljucajClick(TObject *Sender)
{
	Form2->ShowModal();
}
//---------------------------------------------------------------------------

