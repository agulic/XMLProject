
// ************************************************************************************************************** //
//                                                                                                              
//                                               XML Data Binding                                               
//                                                                                                              
//         Generated on: 19.5.2022. 12:34:01                                                                    
//       Generated from: E:\SCHOOL\4.semestar\XML Programiranje\Projekt - Password saver\PasswordSaverXML.xml   
//   Settings stored in: E:\SCHOOL\4.semestar\XML Programiranje\Projekt - Password saver\PasswordSaverXML.xdb   
//                                                                                                              
// ************************************************************************************************************** //

#include <System.hpp>
#pragma hdrstop

#include "PasswordSaverXML.h"


// Global Functions 

_di_IXMLPasswordSaverType __fastcall GetPasswordSaver(Xml::Xmlintf::_di_IXMLDocument Doc)
{
  return (_di_IXMLPasswordSaverType) Doc->GetDocBinding("PasswordSaver", __classid(TXMLPasswordSaverType), TargetNamespace);
};

_di_IXMLPasswordSaverType __fastcall GetPasswordSaver(Xml::Xmldoc::TXMLDocument *Doc)
{
  Xml::Xmlintf::_di_IXMLDocument DocIntf;
  Doc->GetInterface(DocIntf);
  return GetPasswordSaver(DocIntf);
};

_di_IXMLPasswordSaverType __fastcall LoadPasswordSaver(const System::UnicodeString& FileName)
{
  return (_di_IXMLPasswordSaverType) Xml::Xmldoc::LoadXMLDocument(FileName)->GetDocBinding("PasswordSaver", __classid(TXMLPasswordSaverType), TargetNamespace);
};

_di_IXMLPasswordSaverType __fastcall  NewPasswordSaver()
{
  return (_di_IXMLPasswordSaverType) Xml::Xmldoc::NewXMLDocument()->GetDocBinding("PasswordSaver", __classid(TXMLPasswordSaverType), TargetNamespace);
};

// TXMLPasswordSaverType 

void __fastcall TXMLPasswordSaverType::AfterConstruction(void)
{
  RegisterChildNode(System::UnicodeString("Site"), __classid(TXMLSiteType));
  ItemTag = "Site";
  ItemInterface = __uuidof(IXMLSiteType);
  Xml::Xmldoc::TXMLNodeCollection::AfterConstruction();
};

_di_IXMLSiteType __fastcall TXMLPasswordSaverType::Get_Site(int Index)
{
  return (_di_IXMLSiteType) List->Nodes[Index];
};

_di_IXMLSiteType __fastcall TXMLPasswordSaverType::Add()
{
  return (_di_IXMLSiteType) AddItem(-1);
};

_di_IXMLSiteType __fastcall TXMLPasswordSaverType::Insert(const int Index)
{
  return (_di_IXMLSiteType) AddItem(Index);
};

// TXMLSiteType 

System::UnicodeString __fastcall TXMLSiteType::Get_Name()
{
  return GetChildNodes()->Nodes[System::UnicodeString("Name")]->Text;
};

void __fastcall TXMLSiteType::Set_Name(System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("Name")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLSiteType::Get_Username()
{
  return GetChildNodes()->Nodes[System::UnicodeString("Username")]->Text;
};

void __fastcall TXMLSiteType::Set_Username(System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("Username")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLSiteType::Get_Password()
{
  return GetChildNodes()->Nodes[System::UnicodeString("Password")]->Text;
};

void __fastcall TXMLSiteType::Set_Password(System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("Password")]->NodeValue = Value;
};
