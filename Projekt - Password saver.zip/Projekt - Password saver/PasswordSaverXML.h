
// ************************************************************************************************************** //
//                                                                                                              
//                                               XML Data Binding                                               
//                                                                                                              
//         Generated on: 19.5.2022. 12:34:01                                                                    
//       Generated from: E:\SCHOOL\4.semestar\XML Programiranje\Projekt - Password saver\PasswordSaverXML.xml   
//   Settings stored in: E:\SCHOOL\4.semestar\XML Programiranje\Projekt - Password saver\PasswordSaverXML.xdb   
//                                                                                                              
// ************************************************************************************************************** //

#ifndef   PasswordSaverXMLH
#define   PasswordSaverXMLH

#include <System.hpp>
#include <System.Variants.hpp>
#include <Xml.Xmldom.hpp>
#include <Xml.XMLIntf.hpp>
#include <Xml.XMLDoc.hpp>
#include <XMLNodeImp.h>
#include <Xml.xmlutil.hpp>


// Forward Decls 

__interface IXMLPasswordSaverType;
typedef System::DelphiInterface<IXMLPasswordSaverType> _di_IXMLPasswordSaverType;
__interface IXMLSiteType;
typedef System::DelphiInterface<IXMLSiteType> _di_IXMLSiteType;

// IXMLPasswordSaverType 

__interface INTERFACE_UUID("{6A138A14-230A-480E-A5EC-C6B33DAA13A8}") IXMLPasswordSaverType : public Xml::Xmlintf::IXMLNodeCollection
{
public:
public:
  // Property Accessors 
  virtual _di_IXMLSiteType __fastcall Get_Site(int Index) = 0;
  // Methods & Properties 
  virtual _di_IXMLSiteType __fastcall Add() = 0;
  virtual _di_IXMLSiteType __fastcall Insert(const int Index) = 0;
  __property _di_IXMLSiteType Site[int Index] = { read=Get_Site };/* default */
};

// IXMLSiteType 

__interface INTERFACE_UUID("{5505738A-C18A-4E9A-B000-B6BB8B9A9C4C}") IXMLSiteType : public Xml::Xmlintf::IXMLNode
{
public:
  // Property Accessors 
  virtual System::UnicodeString __fastcall Get_Name() = 0;
  virtual System::UnicodeString __fastcall Get_Username() = 0;
  virtual System::UnicodeString __fastcall Get_Password() = 0;
  virtual void __fastcall Set_Name(System::UnicodeString Value) = 0;
  virtual void __fastcall Set_Username(System::UnicodeString Value) = 0;
  virtual void __fastcall Set_Password(System::UnicodeString Value) = 0;
  // Methods & Properties 
  __property System::UnicodeString Name = { read=Get_Name, write=Set_Name };
  __property System::UnicodeString Username = { read=Get_Username, write=Set_Username };
  __property System::UnicodeString Password = { read=Get_Password, write=Set_Password };
};

// Forward Decls 

class TXMLPasswordSaverType;
class TXMLSiteType;

// TXMLPasswordSaverType 

class TXMLPasswordSaverType : public Xml::Xmldoc::TXMLNodeCollection, public IXMLPasswordSaverType
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLPasswordSaverType 
  virtual _di_IXMLSiteType __fastcall Get_Site(int Index);
  virtual _di_IXMLSiteType __fastcall Add();
  virtual _di_IXMLSiteType __fastcall Insert(const int Index);
public:
  virtual void __fastcall AfterConstruction(void);
};

// TXMLSiteType 

class TXMLSiteType : public Xml::Xmldoc::TXMLNode, public IXMLSiteType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLSiteType 
  virtual System::UnicodeString __fastcall Get_Name();
  virtual System::UnicodeString __fastcall Get_Username();
  virtual System::UnicodeString __fastcall Get_Password();
  virtual void __fastcall Set_Name(System::UnicodeString Value);
  virtual void __fastcall Set_Username(System::UnicodeString Value);
  virtual void __fastcall Set_Password(System::UnicodeString Value);
};

// Global Functions 

_di_IXMLPasswordSaverType __fastcall GetPasswordSaver(Xml::Xmlintf::_di_IXMLDocument Doc);
_di_IXMLPasswordSaverType __fastcall GetPasswordSaver(Xml::Xmldoc::TXMLDocument *Doc);
_di_IXMLPasswordSaverType __fastcall LoadPasswordSaver(const System::UnicodeString& FileName);
_di_IXMLPasswordSaverType __fastcall  NewPasswordSaver();

#define TargetNamespace ""

#endif